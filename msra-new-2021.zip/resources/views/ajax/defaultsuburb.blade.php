<div class="form-group">
    <label for="suburb">Suburbs :</label>
    <select name="suburb" id="suburb" class="form-control">
        <option value="0">Select Suburb</option>
    </select>
</div>