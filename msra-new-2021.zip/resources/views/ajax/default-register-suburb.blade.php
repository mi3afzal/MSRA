<div class="input-group mb-3">
    <select name="suburb" id="suburb" class="select2 form-control">
        <option value="">Select Suburb</option>
    </select>
    <div class="input-group-append">
        <div class="input-group-text">
            <span class="fas fa-directions"></span>
        </div>
    </div>
</div>