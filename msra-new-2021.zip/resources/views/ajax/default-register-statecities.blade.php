<div class="input-group mb-3">
    <select name="city" id="city" class="select2 form-control">
        <option value="">Select City</option>
    </select>
    <div class="input-group-append">
        <div class="input-group-text">
            <span class="fas fa-map-signs"></span>
        </div>
    </div>
</div>