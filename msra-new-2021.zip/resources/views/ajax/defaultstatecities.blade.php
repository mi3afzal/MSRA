<div class="form-group">
    <label for="city">Cities :</label>
    <select name="cities" id="cities" class="form-control">
        <option value="">Select City</option>
    </select>
</div>